import React from 'react'

const notFound = () => {
    return (
        <div>
            <h1>Error code 404. Resource not found.</h1>
        </div>
    )
}
export default notFound
