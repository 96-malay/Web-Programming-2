import React from 'react'

function BadIP() {
    return (
        <div>
            <p>Error code 400. Please enter valid page number.</p>
        </div>
    )
}

export default BadIP
