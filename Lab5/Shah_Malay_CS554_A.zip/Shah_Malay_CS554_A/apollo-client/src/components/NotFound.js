import React from 'react'

function NotFound() {
    return (
        <div>
            <p>Error code 404. Resource not found.</p>
        </div>
    )
}

export default NotFound
