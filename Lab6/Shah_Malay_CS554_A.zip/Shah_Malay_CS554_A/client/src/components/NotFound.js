import React from "react";

function NotFound() {
  return <h1>Error: 404: The requested resource is not available</h1>;
}

export default NotFound;
