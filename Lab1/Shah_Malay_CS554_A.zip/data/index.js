const blog = require('./blog')

module.exports = {
    blog : blog
}